package com.cs442.nbrahman.assignment2;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class OrderConfirmation extends AppCompatActivity {

	ArrayList<MenuItem> lstSelMenuItems = new ArrayList<MenuItem> ();
	ListView lvMenu;
	CustomAdapter customAdaptor;
	double dblOrderValue=0;
	Activity context = this;
	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate (savedInstanceState);
		setContentView (R.layout.activity_order_confirmation);
		lstSelMenuItems.addAll ((ArrayList<MenuItem>)getIntent ().getSerializableExtra ("lstSelMenuItems"));

		lvMenu=(ListView) findViewById(R.id.lstSelItems);
		customAdaptor = new CustomAdapter(this, android.R.layout.simple_list_item_1, lstSelMenuItems, lvMenu);
		lvMenu.setAdapter (customAdaptor);

		lvMenu.setEnabled (false);

		Button btnCancel = (Button)findViewById (R.id.btnCancel);
		Button btnConfirmOrder = (Button)findViewById (R.id.btnConfirmOrder);

		btnCancel.setOnClickListener (new View.OnClickListener () {
			@Override
			public void onClick (View v) {
				onBackPressed ();
			}
		});

		btnConfirmOrder.setOnClickListener (new View.OnClickListener () {
			@Override
			public void onClick (View v) {
				for (int i=0;i<lstSelMenuItems.size ();i++)
				{
					dblOrderValue += Double.parseDouble (lstSelMenuItems.get(i).price);
				}
				Intent intent = context.getIntent ();
				intent.putExtra ("TotalOrderValue", dblOrderValue);
				context.setResult (RESULT_OK, intent);
				finish();
			}
		});
	}
}
