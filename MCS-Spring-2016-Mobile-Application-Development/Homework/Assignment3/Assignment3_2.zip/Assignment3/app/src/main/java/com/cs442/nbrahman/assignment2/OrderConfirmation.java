package com.cs442.nbrahman.assignment2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;

class SelMenuCustomAdapter extends ArrayAdapter<MenuItem> {
	ArrayList<SelMenuItem> lstSelMenuItems;
	ListView lstSelMenu;
	Activity activity;
	private static LayoutInflater inflater=null;
	double dblTotalOrderValue=0;
	public SelMenuCustomAdapter(Activity actSelected, int resource, ArrayList<SelMenuItem> arrlstSelMenuItems, ListView lstSelMenu) {
		super(actSelected, resource);
		this.lstSelMenu = lstSelMenu;
		lstSelMenuItems=arrlstSelMenuItems;
		activity=actSelected;
		inflater = (LayoutInflater) activity.
				getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
	@Override
	public int getCount() {
		return lstSelMenuItems.size();
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public class Holder
	{
		TextView lblName;
		TextView lblPricePerUnit;
		EditText txtQty;
		TextView lblAmount;
	}
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final TextView lblTotalOrderValue = (TextView) activity.findViewById (R.id.lblTotalOrderValue);
		final Holder holder=new Holder();
		final View rowView;
		final SelMenuItem curMenuItem = lstSelMenuItems.get(position);
		rowView = inflater.inflate(R.layout.layout_sel_menu_list, null);
		/*if (position % 2 == 1) {
			rowView.setBackgroundColor(Color.LTGRAY);
		} else {
			rowView.setBackgroundColor(Color.GRAY);
		}*/
		holder.lblName=(TextView) rowView.findViewById(R.id.lblName);
		holder.lblPricePerUnit=(TextView) rowView.findViewById(R.id.lblPricePerUnit);
		holder.lblAmount=(TextView) rowView.findViewById(R.id.lblAmount);
		holder.txtQty=(EditText) rowView.findViewById(R.id.txtQty);
		holder.lblName.setText(curMenuItem.strName);
		holder.lblPricePerUnit.setText ("$" + new DecimalFormat ("#0.00").format (curMenuItem.dblPrice));
		holder.lblAmount.setText ("$" + new DecimalFormat ("#0.00").format (curMenuItem.dblPrice * curMenuItem.dblQty));
		holder.txtQty.setText (new DecimalFormat ("#0.00").format (curMenuItem.dblQty));

		holder.txtQty.addTextChangedListener (new TextWatcher () {
			@Override
			public void beforeTextChanged (CharSequence s, int start, int count, int after) {
				Log.d ("Ass3", "BeforeTextChanged()"+s);
			}

			@Override
			public void onTextChanged (CharSequence s, int start, int before, int count) {
				lstSelMenuItems.get(position).dblQty = Double.parseDouble (s.toString ());
				lstSelMenuItems.get(position).dblAmount = lstSelMenuItems.get(position).dblPrice * lstSelMenuItems.get(position).dblQty;
				holder.lblAmount.setText ("$" + new DecimalFormat ("#0.00").format (lstSelMenuItems.get(position).dblAmount));
				dblTotalOrderValue = 0;
				for (int i = 0; i <lstSelMenuItems.size();i++)
				{
					dblTotalOrderValue += lstSelMenuItems.get (i).dblAmount;
				}
				lblTotalOrderValue.setText ("Total Order Value: $" + String.valueOf (new DecimalFormat ("#0.00").format (dblTotalOrderValue)));
			}

			@Override
			public void afterTextChanged (Editable s) {
			}
		});
		/*rowView.setOnClickListener(new View.OnClickListener () {
			@Override
			public void onClick(View v) {
				Toast.makeText (context, curMenuItem.name + "\t\tPrice: $" + curMenuItem.price + "\n\n" + curMenuItem.description, Toast.LENGTH_LONG).show();
			}
		});

		rowView.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				new AlertDialog.Builder(context)
						.setIcon(android.R.drawable.ic_dialog_alert)
						.setMessage("Are you sure you want to delete this Menu Menu item?")
						.setPositiveButton("Yes", new DialogInterface.OnClickListener()
						{
							@Override
							public void onClick(DialogInterface dialog, int which) {
								((MainActivity) context).removeMenuItem(position);
								Toast.makeText(context,  curMenuItem.name + " removed from Menu.", Toast.LENGTH_LONG).show();
							}
						})
						.setNegativeButton("No", null)
						.show();

				return false;
			}
		});*/
		return rowView;
	}
}

public class OrderConfirmation extends AppCompatActivity {

	ArrayList<SelMenuItem> lstSelMenuItems = new ArrayList<SelMenuItem> ();
	ListView lvSelMenu;
	SelMenuCustomAdapter selMenuCustomAdapter;
	double dblOrderValue=0;
	Activity context = this;
	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate (savedInstanceState);
		setContentView (R.layout.activity_order_confirmation);
		lstSelMenuItems.addAll ((ArrayList<SelMenuItem>) getIntent ().getSerializableExtra ("lstSelMenuItems"));

		getSupportActionBar ().setDisplayHomeAsUpEnabled (true);

		lvSelMenu=(ListView) findViewById(R.id.lstSelItems);
		selMenuCustomAdapter = new SelMenuCustomAdapter(this, R.layout.layout_sel_menu_list, lstSelMenuItems, lvSelMenu);
		lvSelMenu.setAdapter (selMenuCustomAdapter);

		lvSelMenu.setEnabled (false);

		Button btnCancel = (Button)findViewById (R.id.btnCancel);
		Button btnConfirmOrder = (Button)findViewById (R.id.btnConfirmOrder);
		for (int i=0;i<lstSelMenuItems.size ();i++)
		{
			lstSelMenuItems.get(i).dblAmount = lstSelMenuItems.get(i).dblPrice * lstSelMenuItems.get(i).dblQty;
			dblOrderValue += lstSelMenuItems.get (i).dblAmount;
		}
		TextView lblTotalOrderValue = (TextView)findViewById (R.id.lblTotalOrderValue);
		lblTotalOrderValue.setText ("Total Order Value: $" + String.valueOf (new DecimalFormat ("#0.00").format (dblOrderValue)));

		btnCancel.setOnClickListener (new View.OnClickListener () {
			@Override
			public void onClick (View v) {
				onBackPressed ();
			}
		});

		btnConfirmOrder.setOnClickListener (new View.OnClickListener () {
			@Override
			public void onClick (View v) {
				new AlertDialog.Builder(context)
						.setIcon(android.R.drawable.ic_dialog_alert)
						.setMessage("Are you sure you want to confirm this order?")
						.setPositiveButton("Yes", new DialogInterface.OnClickListener()
						{
							@Override
							public void onClick(DialogInterface dialog, int which) {
								dblOrderValue = 0;
								for (int i=0;i<lstSelMenuItems.size ();i++)
								{
									lstSelMenuItems.get(i).dblAmount = lstSelMenuItems.get(i).dblPrice * lstSelMenuItems.get(i).dblQty;
									dblOrderValue += lstSelMenuItems.get (i).dblAmount;
								}
								TextView lblTotalOrderValue = (TextView)findViewById (R.id.lblTotalOrderValue);
								lblTotalOrderValue.setText ("Total Order Value: $" + String.valueOf (new DecimalFormat ("#0.00").format (dblOrderValue)));
								Intent intent = context.getIntent ();
								intent.putExtra ("TotalOrderValue", dblOrderValue);
								context.setResult (RESULT_OK, intent);
								finish();
							}
						})
						.setNegativeButton("No", new DialogInterface.OnClickListener()
						{
							@Override
							public void onClick(DialogInterface dialog, int which) {
								onBackPressed ();
						}
						})
						.show ();
			}
		});
	}

	@Override
	public boolean onOptionsItemSelected(android.view.MenuItem item)
	{
		switch (item.getItemId()) {
			case android.R.id.home:
				// app icon in action bar clicked; go home
				onBackPressed ();
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
}


class SelMenuItem implements Serializable {
	public String strName;
	public String strDesc;
	public double dblPrice;
	public double dblQty=0;
	public double dblAmount=0;
}